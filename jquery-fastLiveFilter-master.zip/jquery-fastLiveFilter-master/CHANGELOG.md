v1.0.3 / 2012-06-11:

- Make options arg optional (fixes #4)
- Fix accidental global

v1.0.2 / 2012-01-24:

- Add package.json for new/upcoming plugins.jquery.com

v1.0.1 / 2011-12-07:

- Add support for Win/IE (fixes #3)

v1.0.0 / 2011-11-05:

- Initial version with support for lists and similar DOM elements.
- Customizable timeout option.
- Customizable callback function.
- Speed: ~20-600x faster than the competition.
